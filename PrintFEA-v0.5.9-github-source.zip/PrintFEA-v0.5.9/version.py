"""PrintFEA release version."""
__version__ = "0.5.9"
